#ifndef _CMD_FUNCTIONS_H_
#define _CMD_FUNCTIONS_H_

unsigned int cmd_compare(char *);
void cmd_end_compare(void);
float getPressure(int ADCdata, int TM, long useOffset);

#endif
